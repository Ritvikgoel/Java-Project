package hotel;

public class Hotel {

    public static void main(String[] args) {
     
		new Login().setVisible(true) ;// This makes the jFrame Login visible
    }
    
}
